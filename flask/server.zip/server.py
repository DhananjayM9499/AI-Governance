from fastapi import FastAPI, UploadFile, File, Form, HTTPException
import pandas as pd
from typing import List, Dict
from fastapi.middleware.cors import CORSMiddleware
import re
from pydantic import BaseModel
from fastapi.responses import JSONResponse

app = FastAPI()

origins = [
    "http://localhost",  # Add the URL of your React frontend
    "http://localhost:3000",  # Add the URL of your React development server
]

# Configure CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

data = [
    ("European Union", "GDPR", 0.04, 20000000000, "Total Revenue", "EUR", 0.92),
    (
        "United States",
        "State-specific regulations (e.g., CCPA)",
        "Varied",
        8000,
        "Per violation",
        "USD",
        1,
    ),
    ("Canada", "PIPEDA", 0, 100000, "Total Revenue", "CAD", 1.25),
    (
        "China",
        "Cybersecurity Law, Personal Information Security Specification",
        0.05,
        561183700,
        "Total Revenue",
        "CNY",
        6.45,
    ),
    (
        "India",
        "Personal Data Protection Bill (proposed)",
        0.04,
        150000000,
        "total worldwide turnover",
        "INR",
        73,
    ),
    (
        "Australia",
        "Privacy Act, NDB scheme",
        0.04,
        50000000,
        "Annual global turnover",
        "AUD",
        1.35,
    ),
    # Add more data here...
]

columns = [
    "Country",
    "Data Privacy Regulation",
    "Privacy Penalties (%)",
    "Privacy Penalties Amount",
    "Unit",
    "Currency",
    "Conversion from US$ to Country Currency",
]


class PenaltyCalculationRequest(BaseModel):
    annual_usd: float
    num_violations: int


def calculate_penalty(row, annual_usd, num_violations):
    penalty_percent = row["Privacy Penalties (%)"]
    penalty_amount = row["Privacy Penalties Amount"]
    currency = row["Currency"]
    conversion_rate = row["Conversion from US$ to Country Currency"]

    if penalty_percent == "Varied":
        penalty = penalty_amount * num_violations
    else:
        penalty_percentage = penalty_percent
        penalty_based_on_percentage = penalty_percentage * annual_usd * conversion_rate
        penalty = max(penalty_based_on_percentage, penalty_amount)

    return penalty


# Define a function to analyze columns (all columns are assumed to be discrete)
def analyze_columns(data):
    return data.columns.tolist(), []


# Define a function to calculate percentage scores for a column
def calculate_percentage_scores(column):
    if column.dtype == "object":
        value_counts = column.value_counts(normalize=True) * 100
        return value_counts
    else:
        return None


# Define a function to calculate fairness score
def calculate_fairness_score(scores):
    sorted_scores = scores.sort_values(ascending=False)
    if len(sorted_scores) >= 2:
        return sorted_scores.iloc[0] - sorted_scores.iloc[1]
    return 0


# Define a function to calculate explicit fairness formula
def calculate_explicit_fairness_formula(scores):
    if len(scores) >= 2:
        max_score = scores.iloc[0]
        second_max_score = scores.iloc[1]
        return f"{second_max_score:.2f}% / {max_score:.2f}%"
    return "N/A"


# Define a function to calculate fairness metrics
# Define the calculate_fairness_metrics function
def calculate_fairness_metrics(
    data: pd.DataFrame,
    algorithm_column: str,
    dataset_column: str,
    predicted_column: str,
    actual_column: str,
) -> Dict:
    fairness_metrics = {}  # Initialize an empty dictionary for the metrics

    # Group data by unique algorithm-dataset pairs
    unique_pairs = data.groupby([algorithm_column, dataset_column])

    for (algorithm, dataset), group_data in unique_pairs:
        # Calculate fairness metrics for each unique pair
        true_positive = sum(
            (group_data[predicted_column] == 1) & (group_data[actual_column] == 1)
        )
        false_positive = sum(
            (group_data[predicted_column] == 1) & (group_data[actual_column] == 0)
        )
        true_negative = sum(
            (group_data[predicted_column] == 0) & (group_data[actual_column] == 0)
        )
        false_negative = sum(
            (group_data[predicted_column] == 0) & (group_data[actual_column] == 1)
        )

        # Calculate fairness metrics (e.g., True Positive Rate and False Positive Rate)
        tpr = (
            true_positive / (true_positive + false_negative)
            if (true_positive + false_negative) > 0
            else 0
        )
        fpr = (
            false_positive / (false_positive + true_negative)
            if (false_positive + true_negative) > 0
            else 0
        )

        # Store the calculated metrics in the fairness_metrics dictionary
        fairness_metrics[f"Fairness Metrics for {algorithm} on {dataset}"] = {
            "True Positive Rate ": tpr,
            "False Positive Rate ": fpr,
            # Add more fairness metrics as needed
        }

    return fairness_metrics


# Define a function to analyze bias
def analyze_bias(df: pd.DataFrame) -> List[Dict]:
    # Initialize an empty list to store the results
    results = []

    # Group the DataFrame by 'Algorithm Name' and 'Dataset' columns
    grouped = df.groupby(["Algorithm Name", "Dataset"])

    for (algorithm_name, dataset), dataset_group in grouped:
        result_dict = {
            "Algorithm Name": algorithm_name,
            "Dataset": dataset,
            "Results": [],
        }

        # Iterate through the columns starting from the 3rd column (index 2)
        for variable, values in dataset_group.iloc[:, 2:].items():
            # Calculate the accuracy and reliability metrics
            num_ones = values.sum()
            total_observations = len(values)
            accuracy = num_ones / total_observations
            reliability = num_ones / values.count()

            # Append the results for this variable
            result_dict["Results"].append(
                {"Variable": variable, "Accuracy": accuracy, "Reliability": reliability}
            )

        # Append the results for this algorithm-dataset pair to the overall results list
        results.append(result_dict)

    return results


def identify_sensitive_columns(df: pd.DataFrame) -> Dict:
    sensitive_data_columns = set()
    bias_data_columns = set()
    behavioral_analysis_columns = set()
    potential_cyber_attack_columns = set()
    recommendations = {}

    # Function to check for patterns indicative of sensitive data
    def check_for_sensitive_patterns(text, column_name):
        patterns = {
            "Email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b",
            "Phone": r"\b\d{3}-\d{3}-\d{4}\b",
            "DOB": r"\b\d{4}-\d{2}-\d{2}\b",
            "CreditCard": r"\b\d{4}-\d{4}-\d{4}-\d{4}\b",
            "SSN": r"\b\d{3}-\d{2}-\d{4}\b",
        }
        for pattern_name, pattern in patterns.items():
            if re.search(pattern, text):
                sensitive_data_columns.add(column_name)
                recommendations[
                    column_name
                ] = f"Apply data anonymization, encryption, and access controls for {pattern_name} data."

    # Function to check for columns that may indicate bias
    def check_for_bias_columns(column_name):
        # Check if column_name matches known bias indicators
        bias_indicators = ["Gender", "Race", "Religion"]
        if column_name in bias_indicators:
            bias_data_columns.add(column_name)
            recommendations[
                column_name
            ] = "Monitor for bias and ensure fair treatment in decision-making processes."

    # Function to check for columns suitable for behavioral analysis
    def check_for_behavioral_analysis_columns(column_name):
        # Check if column_name contains behavior-related keywords
        behavior_keywords = ["Behavior", "Activity"]
        for keyword in behavior_keywords:
            if keyword in column_name:
                behavioral_analysis_columns.add(column_name)
                recommendations[
                    column_name
                ] = "Perform behavioral analysis to gain insights for decision support."

    # Function to check for columns that may pose potential cybersecurity risks
    def check_for_cyber_attack_columns(column_name):
        # Check if column_name contains indicators of potential cyber attack vectors
        cyber_attack_indicators = ["IPAddresses", "FileLinks"]
        if column_name in cyber_attack_indicators:
            potential_cyber_attack_columns.add(column_name)
            recommendations[
                column_name
            ] = "Implement cybersecurity measures to protect against potential threats."

    # Analyze the data for patterns and potential issues
    for column in df.columns:
        for value in df[column]:
            if isinstance(value, str):
                check_for_sensitive_patterns(value, column)
            check_for_bias_columns(column)
            check_for_behavioral_analysis_columns(column)
            check_for_cyber_attack_columns(column)

    result = {
        "Private Sensitive Data": list(sensitive_data_columns),
        "Bias Data": list(bias_data_columns),
        "Behavioral Analysis Data": list(behavioral_analysis_columns),
        "Potential Cyber Security Attack Data": list(potential_cyber_attack_columns),
        "Recommendations": recommendations,
    }

    return result


@app.post("/calculate_penalty/")
async def calculate_penalties(request_data: PenaltyCalculationRequest):
    annual_usd = request_data.annual_usd
    num_violations = request_data.num_violations

    if not isinstance(annual_usd, (float, int)) or annual_usd <= 0:
        raise HTTPException(
            status_code=422,
            detail="Invalid input. Annual USD must be a positive number.",
        )

    if num_violations < 0:
        raise HTTPException(
            status_code=422,
            detail="Invalid input. Number of violations must be non-negative.",
        )

    # Create a new DataFrame for each calculation
    df = pd.DataFrame(data, columns=columns)

    # Calculate penalties and cumulative penalty
    df["Penalty"] = df.apply(
        calculate_penalty, args=(annual_usd, num_violations), axis=1
    )
    df["Converted Penalty"] = (
        df["Penalty"] * df["Conversion from US$ to Country Currency"]
    )
    cumulative_penalty = df["Converted Penalty"].sum()

    # Add Serial Number starting from 1
    df.insert(0, "Sr No", range(1, 1 + len(df)))

    # Create a dictionary to store results for all countries
    results = {
        "Cumulative Fine Amount (USD)": f"${cumulative_penalty:.2f}",
        "Countries": [],
    }

    # Loop through each country and add its results to the dictionary
    for _, row in df.iterrows():
        country_result = {
            "Country": row["Country"],
            "Data Privacy Regulation": row["Data Privacy Regulation"],
            "Penalty": row["Penalty"],
            "Currency": row["Currency"],
        }
        results["Countries"].append(country_result)

    return results


# Function to classify ranges
def classify_ranges(column, num_ranges=5):
    if column.dtype == "datetime64[ns]":
        if column.dt.time.max() > pd.Timestamp("1900-01-01 00:00:00").time():
            column = column.dt.time
        else:
            column_min = column.min()
            column_max = column.max()
            range_width = (column_max - column_min) / num_ranges
            labels = [
                f"{column_min + i*range_width} to {column_min + (i+1)*range_width}"
                for i in range(num_ranges)
            ]
            return pd.cut(
                column,
                bins=pd.interval_range(
                    start=column_min, freq=range_width, periods=num_ranges
                ),
                labels=labels,
                include_lowest=True,
            )
    else:
        column = column.astype(float)
        column_min = column.min()
        column_max = column.max()
        range_width = (column_max - column_min) / num_ranges
        labels = [
            f"{column_min + i*range_width:.2f} to {column_min + (i+1)*range_width:.2f}"
            for i in range(num_ranges)
        ]
        return pd.cut(column, bins=num_ranges, labels=labels, include_lowest=True)


# Function to calculate percentage scores
def calculate_percentage_scores(data):
    percentage_scores = {}

    for column in data.columns:
        if data[column].dtype == "object":
            value_counts = data[column].value_counts(normalize=True) * 100
            percentage_scores[column] = value_counts
        else:
            ranges = classify_ranges(data[column])
            if ranges is not None:
                range_counts = ranges.value_counts(normalize=True) * 100
                percentage_scores[column] = range_counts

    return percentage_scores


# Function to calculate fairness score
def calculate_fairness_score(scores):
    sorted_scores = scores.sort_values(ascending=False)
    if len(sorted_scores) >= 2:
        max_score = sorted_scores.iloc[0]
        second_max_score = sorted_scores.iloc[1]
        max_indices = sorted_scores[sorted_scores == max_score].index.tolist()
        return {
            "max_score": f"{max_score:.2f}%",
            "max_values": max_indices,
            "fairness_score": f"{second_max_score:.2f}% / {max_score:.2f}%",
        }
    return {"max_score": "N/A", "max_values": [], "fairness_score": "N/A"}


# Function to perform bias analysis and return results as a dictionary
def perform_bias_analysis(
    data, threshold_percentage=50, min_difference_percentage=20, num_ranges=5
):
    percentage_scores = calculate_percentage_scores(data)

    results = {}

    for column in data.columns:
        column_data = {}
        if column in percentage_scores:
            value_counts = percentage_scores[column]
            fairness_info = calculate_fairness_score(value_counts)

            bias = "No Bias"
            if (
                fairness_info["max_score"] != "N/A"
                and float(fairness_info["max_score"][:-1]) > threshold_percentage
                and len(fairness_info["max_values"]) > 1
            ):
                bias = "Potential Bias"

            column_data["Bias Analysis"] = bias
            column_data["Max Percentage"] = fairness_info["max_score"]
            column_data["Max Values"] = fairness_info["max_values"]
            column_data["Fairness Score"] = fairness_info["fairness_score"]
            column_data["Classification Ranges"] = value_counts.to_dict()

        results[column] = column_data

    return results


@app.post("/bias-analysis/")
async def analyze_bias(file: UploadFile):
    try:
        # Read the uploaded CSV file into a DataFrame
        df = pd.read_csv(file.file)

        # Perform bias analysis
        results = perform_bias_analysis(df)

        # Return the results as JSON
        return JSONResponse(content=results)

    except FileNotFoundError:
        return JSONResponse(
            content={"error": "File not found. Please check the file path."}
        )
    except Exception as e:
        return JSONResponse(content={"error": f"An error occurred: {str(e)}"})


# Define the /algorithmAccuracy/ endpoint for checking algorithm accuracy
@app.post("/algorithmAccuracy/")  # Updated endpoint URL here
async def analyze_csv(file: UploadFile):
    try:
        # Read the uploaded CSV file into a DataFrame
        df = pd.read_csv(file.file)
    except Exception as e:
        return {"error": f"Error reading the CSV file: {str(e)}"}

    # Perform bias analysis on the DataFrame
    results = analyze_bias(df)

    # Return the results as JSON
    return {"results": results}


# Define the /calculate_fairness_metrics/ endpoint
@app.post("/calculate_fairness_metrics/")
async def calculate_metrics(file: UploadFile):
    try:
        # Read the uploaded CSV file into a DataFrame
        df = pd.read_csv(file.file)
    except Exception as e:
        return {"error": f"Error reading the CSV file: {str(e)}"}

    # Define the column names
    algorithm_column = "Algorithm"
    dataset_column = "Dataset"
    predicted_column = "Predicted"
    actual_column = "Actual"

    # Check if any of the required columns are missing
    if not all(
        column in df.columns
        for column in [
            algorithm_column,
            dataset_column,
            predicted_column,
            actual_column,
        ]
    ):
        return {
            "error": "One or more required columns are missing in the uploaded CSV."
        }

    try:
        # Call the calculate_fairness_metrics function
        fairness_metrics = calculate_fairness_metrics(
            df, algorithm_column, dataset_column, predicted_column, actual_column
        )
        return fairness_metrics
    except Exception as e:
        return {"error": f"Error calculating fairness metrics: {str(e)}"}


@app.post("/identify_sensitive_columns/")
async def identify_columns(file: UploadFile):
    try:
        # Read the uploaded CSV file into a DataFrame
        df = pd.read_csv(file.file)
    except Exception as e:
        return {"error": f"Error reading the CSV file: {str(e)}"}

    # Identify sensitive columns and provide recommendations
    result = identify_sensitive_columns(df)
    return result


# Run the FastAPI application
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
